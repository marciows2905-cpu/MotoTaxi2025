
Moto Táxi 2025 - Flutter full project scaffold
==============================================

This scaffold contains a full Flutter app with:
- UI for calculating fares (base, km, min)
- History saved in SharedPreferences
- Separate result pages for normal fare and fare+15%+R$1.00
- Info page with 'Clear history' button
- Map screen using flutter_map (OpenStreetMap)
- Placeholder for offline map tiles in assets/tiles/

IMPORTANT: Offline tiles are NOT included. To use offline maps, put tile images into assets/tiles/{z}/{x}/{y}.png
or provide an MBTiles file and adapt the tile provider.
To build APK use GitHub Actions workflow included (.github/workflows/build_apk.yml).

Files included:
- lib/main.dart
- android/app/src/main/AndroidManifest.xml
- .github/workflows/build_apk.yml
- pubspec.yaml
- README.md
- assets (logo placeholder + tiles folder)
