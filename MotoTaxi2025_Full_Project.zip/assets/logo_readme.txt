Replace this with your app icon/logo at assets/logo.png
Put offline tile images under assets/tiles/{z}/{x}/{y}.png
