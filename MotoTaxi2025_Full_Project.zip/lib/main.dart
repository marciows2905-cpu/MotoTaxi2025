
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

void main() {
  runApp(const MotoTaxiApp());
}

class MotoTaxiApp extends StatelessWidget {
  const MotoTaxiApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Moto Táxi 2025',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const HomePage(),
    );
  }
}

class RideEntry {
  final String destino;
  final double km;
  final double min;
  final double normal;
  final double vermelha;
  final int ts;

  RideEntry(this.destino, this.km, this.min, this.normal, this.vermelha, this.ts);

  Map<String,dynamic> toJson() => {
    'destino': destino, 'km': km, 'min': min, 'normal': normal, 'verm': vermelha, 'ts': ts
  };

  static RideEntry fromJson(Map<String,dynamic> j) => RideEntry(
    j['destino'], (j['km'] as num).toDouble(), (j['min'] as num).toDouble(),
    (j['normal'] as num).toDouble(), (j['verm'] as num).toDouble(), j['ts']
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final destinoCtrl = TextEditingController();
  final kmCtrl = TextEditingController();
  final minCtrl = TextEditingController();
  List<RideEntry> history = [];
  static const double base = 3.00;
  static const double perKm = 0.50;
  static const double perMin = 0.10;
  static const double perc = 0.15;
  static const double fix = 1.00;

  @override
  void initState(){
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    try {
      final sp = await SharedPreferences.getInstance();
      final raw = sp.getString('mt_history_v1') ?? '[]';
      final List parsed = json.decode(raw);
      setState((){
        history = parsed.map((e)=>RideEntry.fromJson(Map<String,dynamic>.from(e))).toList();
      });
    } catch(e) {
      // ignore
    }
  }

  Future<void> _saveHistory() async {
    final sp = await SharedPreferences.getInstance();
    final raw = json.encode(history.map((e)=>e.toJson()).toList());
    await sp.setString('mt_history_v1', raw);
  }

  void _calculateAndSave(){
    final km = double.tryParse(kmCtrl.text) ?? 0.0;
    final mn = double.tryParse(minCtrl.text) ?? 0.0;
    final destino = destinoCtrl.text.trim().isEmpty ? '-' : destinoCtrl.text.trim();
    final normal = (base + (km*perKm) + (mn*perMin));
    final verm = (normal * (1 + perc)) + fix;
    final e = RideEntry(destino, km, mn, double.parse(normal.toStringAsFixed(2)), double.parse(verm.toStringAsFixed(2)), DateTime.now().millisecondsSinceEpoch);
    setState(()=> history.insert(0, e));
    _saveHistory();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cálculo realizado e salvo no histórico')));
  }

  void _clearHistory(){
    setState(()=> history.clear());
    _saveHistory();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Histórico apagado com sucesso')));
  }

  void _openNormal(){
    if(history.isEmpty){ ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nenhum cálculo salvo.'))); return; }
    Navigator.push(context, MaterialPageRoute(builder: (_)=> ResultPage(entry: history.first, showVermelha:false)));
  }

  void _openVermelha(){
    if(history.isEmpty){ ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nenhum cálculo salvo.'))); return; }
    Navigator.push(context, MaterialPageRoute(builder: (_)=> ResultPage(entry: history.first, showVermelha:true)));
  }

  void _startRoute(){
    Navigator.push(context, MaterialPageRoute(builder: (_)=> const MapScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Moto Táxi 2025 – Sistema Inteligente')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(controller: destinoCtrl, decoration: const InputDecoration(labelText: 'Destino da corrida')),
            const SizedBox(height:8),
            Row(children: [
              Expanded(child: TextField(controller: kmCtrl, decoration: const InputDecoration(labelText:'Distância (km)'), keyboardType: TextInputType.number)),
              const SizedBox(width:10),
              Expanded(child: TextField(controller: minCtrl, decoration: const InputDecoration(labelText:'Tempo (min)'), keyboardType: TextInputType.number)),
            ]),
            const SizedBox(height:12),
            Wrap(spacing:10, runSpacing:10, children: [
              ElevatedButton(onPressed: _calculateAndSave, child: const Text('🔢 Calcular')),
              ElevatedButton.styleFrom(primary: Colors.green[400]);
              ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.green[400]), onPressed: _openNormal, child: const Text('🟩 Bandeira Verde')),
              ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.red[400]), onPressed: _openVermelha, child: const Text('🟥 Bandeira Vermelha')),
              ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.blue), onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=> InfoPage(onClear: _clearHistory))), child: const Text('💙 Informações')),
              ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.grey), onPressed: _startRoute, child: const Text('📍 Iniciar Rota')),
            ]),
            const SizedBox(height:20),
            const Text('Resumo (últimas corridas):', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height:8),
            ...history.take(5).map((e){
              final dt = DateFormat('dd/MM/yyyy HH:mm').format(DateTime.fromMillisecondsSinceEpoch(e.ts));
              return ListTile(title: Text('${e.destino}'), subtitle: Text('$dt'), trailing: Column(children:[Text('N: R\$ ${e.normal.toStringAsFixed(2)}', style: const TextStyle(color:Colors.green)), Text('V: R\$ ${e.vermelha.toStringAsFixed(2)}', style: TextStyle(color:Colors.red[700]))], mainAxisSize: MainAxisSize.min),);
            }).toList()
          ],
        ),
      ),
    );
  }
}

class ResultPage extends StatelessWidget{
  final RideEntry entry;
  final bool showVermelha;
  const ResultPage({required this.entry, required this.showVermelha, super.key});

  @override
  Widget build(BuildContext context){
    final dt = DateFormat('HH:mm').format(DateTime.fromMillisecondsSinceEpoch(entry.ts));
    final date = DateFormat('dd MMMM yyyy', 'pt_BR').format(DateTime.fromMillisecondsSinceEpoch(entry.ts));
    return Scaffold(
      appBar: AppBar(title: Text(showVermelha ? 'Tarifa com Acréscimo' : 'Tarifa Normal')),
      body: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(entry.destino, style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height:6),
          Row(children:[Text(dt, style: TextStyle(color: Colors.blue[700], fontWeight: FontWeight.w800)), const SizedBox(width:8), Text(date, style: TextStyle(color: Colors.blue[700], fontWeight: FontWeight.w800))]),
          const SizedBox(height:12),
          if(!showVermelha) ...[
            const Text('Tarifa Normal', style: TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height:8),
            Text('Base: R\$ 3.00'),
            Text('Distância: ${entry.km} × 0.50 = R\$ ${(entry.km*0.5).toStringAsFixed(2)}'),
            Text('Tempo: ${entry.min} × 0.10 = R\$ ${(entry.min*0.1).toStringAsFixed(2)}'),
            const Divider(),
            const Text('VALOR FINAL', style: TextStyle(fontWeight: FontWeight.w900, color: Colors.green, fontSize:20)),
            Text('R\$ ${entry.normal.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w900, color: Colors.green, fontSize:28)),
          ] else ...[
            const Text('Tarifa com 15% × 1.15 + R\$1,00', style: TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height:8),
            Text('Tarifa Normal: R\$ ${entry.normal.toStringAsFixed(2)}'),
            _finalCalcBox(entry),
            const Divider(),
            const Text('VALOR FINAL', style: TextStyle(fontWeight: FontWeight.w900, color: Colors.red, fontSize:20)),
            Text('R\$ ${entry.vermelha.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w900, color: Colors.red, fontSize:28)),
          ],
          const Spacer(),
          ElevatedButton(onPressed: ()=> Navigator.pop(context), child: const Text('⬅️ Voltar'))
        ],),
      ),
    );
  }

  Widget _finalCalcBox(RideEntry e){
    final acr = (e.normal * 0.15);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
      Text('Acréscimo 15%: R\$ ${acr.toStringAsFixed(2)}'),
      const SizedBox(height:4),
      const Text('Taxa fixa: R\$ 1.00'),
    ]);
  }
}

class InfoPage extends StatelessWidget{
  final VoidCallback onClear;
  const InfoPage({required this.onClear, super.key});
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: const Text('Informações')),
      body: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children:[
          const Text('Moto Táxi 2025', style: TextStyle(fontSize:18, fontWeight: FontWeight.w900)),
          const SizedBox(height:8),
          Expanded(child: SingleChildScrollView(child: Text('''O Moto Táxi 2025 é um sistema desenvolvido especialmente para o profissional autônomo que depende da precisão, segurança e transparência na hora de calcular o valor de uma corrida.
Cada detalhe deste aplicativo foi criado para garantir que o piloto e o passageiro tenham confiança total nos valores apresentados, evitando divergências, mal-entendidos ou cálculos improvisados.

O objetivo do Moto Táxi 2025 é proporcionar uma ferramenta simples, rápida e extremamente confiável, capaz de funcionar até mesmo offline, garantindo que o profissional nunca fique na mão — seja em lugares sem sinal, estradas rurais, bairros afastados ou zonas onde a internet não funciona.

Por que existe o acréscimo de 15% × 1,15 + R$1,00?
Esse acréscimo não é apenas um valor adicional. Ele representa os custos reais, riscos e desgaste que fazem parte da rotina de um Moto Táxi:

✔️ Manutenção preventiva constante
✔️ Troca periódica de óleo
✔️ Desgaste natural de pneus, freios e peças
✔️ Consumo de combustível
✔️ Corridas em dias de chuva
✔️ Estradas de terra, lama ou trechos sem asfalto
✔️ Atendimento noturno
✔️ Domingos e feriados
✔️ Alto índice de acidentes envolvendo motociclistas
✔️ Risco de assalto — proteção do piloto e passageiro

Cada corrida tem um custo real para o profissional. O acréscimo garante que o piloto continue oferecendo segurança, qualidade e um serviço profissional, sem prejuízos.
'''))),
          Row(children:[
            ElevatedButton(onPressed: ()=> Navigator.pop(context), child: const Text('⬅️ Voltar')),
            const SizedBox(width:10),
            ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.blue), onPressed: (){ showDialog(context: context, builder: (_)=> AlertDialog(title: const Text('Confirmar'), content: const Text('Apagar todo o histórico?'), actions: [TextButton(onPressed: ()=> Navigator.pop(context), child: const Text('Cancelar')), TextButton(onPressed: (){ onClear(); Navigator.pop(context); }, child: const Text('Apagar')]) ); }, child: const Text('🔵 Limpar Histórico'))
          ],)
        ],),
      ),
    );
  }
}

class MapScreen extends StatefulWidget{
  const MapScreen({super.key});
  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  // Placeholder center coordinates (Teresina region). For offline tiles, place tiles in assets/tiles/{z}/{x}/{y}.png
  final center = LatLng(-5.09194, -42.8037);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Navegação Offline')),
      body: FlutterMap(
        options: MapOptions(center: center, zoom: 12),
        children: [
          TileLayer(
            // online default - replace with file:// path for offline tiles or a local tile provider
            urlTemplate: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
            subdomains: const ['a','b','c'],
            userAgentPackageName: 'com.mototaxi.mototaxi2025',
          ),
          MarkerLayer(markers: [
            Marker(point: center, width: 40, height: 40, builder: (_)=> const Icon(Icons.location_on, color: Colors.red, size: 40))
          ]),
        ],
      ),
    );
  }
}
